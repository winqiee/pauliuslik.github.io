# electronjs.org-old

> **Warning**
> 
> This repository hosts an old version of Electron's website. For the source code of the current website, see the [`electron/website`](https://github.com/electron/website) repository.

## License

[MIT](LICENSE.md)
