module.exports = (req, res) => {
  res.render('devtron', req.context)
}
