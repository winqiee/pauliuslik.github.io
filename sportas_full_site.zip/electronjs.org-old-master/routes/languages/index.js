module.exports = (req, res) => {
  res.render('languages/index', req.context)
}
