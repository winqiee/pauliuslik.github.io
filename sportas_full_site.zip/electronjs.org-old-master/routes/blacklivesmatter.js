module.exports = (req, res) => {
  res.render('blm', req.context)
}
