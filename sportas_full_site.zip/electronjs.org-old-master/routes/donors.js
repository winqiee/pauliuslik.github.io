module.exports = (req, res) => {
  res.render('donors', req.context)
}
