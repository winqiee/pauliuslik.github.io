module.exports = (req, res) => {
  res.render('governance/index', req.context)
}
