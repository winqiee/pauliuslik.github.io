module.exports = {
  app: require('./app.hbs'),
  api: require('./api.hbs'),
  package: require('./package.hbs'),
  tutorial: require('./tutorial.hbs'),
}
