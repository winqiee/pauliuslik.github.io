# /templates

This directory contains Handlebars templates to be used in the browser
by Algolia search. They are all exported in a module that can be accessed with
`require('./templates')`